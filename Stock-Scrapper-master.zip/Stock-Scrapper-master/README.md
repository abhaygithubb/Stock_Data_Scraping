# Stock-Scrapper
A Python based project to scrape stock data, alert when %Ch change by 2% or more, compute MACD indicators and plot them.

![MACD Indicators](MACD.png)
